import csv
import json
import re

raw_data = """id,nom,tags,importance,series,valeur,type,repos,description,video,frequence
1,Exercice de Kegel avec Expiration,"Santé Pelvienne, Respiration, Alta",1-Haute,1,10,répétitions,60,"Contractez le plancher pelvien pendant l'expiration buccale, puis relâchez complètement pendant l'inspiration nasale. Gardez le ventre souple.",kegel+breathing+physio,5
2,Rotation des hanches assis,"Santé Pelvienne, Mobilité, Alta",1-Haute,1,20,répétitions,30,"Assis sur le ballon de stabilité, effectuez de larges cercles avec le bassin pour mobiliser les hanches et le bas du dos.",seated+ball+hip+rotation,5
3,Mouvement de la Pagaie (Infini),"Thoracique, Mobilité, Alta",1-Haute,1,20,répétitions,30,Maintenez vos mains sur vos coudes opposés et dessinez un chiffre huit horizontal (symbole de l'infini) devant vous. Laissez le tronc suivre.,thoracic+rotation+paddle,5
4,Étirement du dos vers l'arrière,"Postural, Extension, Alta",1-Haute,1,10,répétitions,45,Effectuez une extension du dos en vous appuyant sur le ballon de stabilité pour ouvrir la cage thoracique et étirer les abdominaux.,seated+back+extension,5
5,Équilibre sur ballon de stabilité,"Stabilité, Core, Alta",2-Moyenne,1,60,secondes,45,"Maintenez une position stable sur le ballon. Pour augmenter la difficulté, essayez de lever un talon ou un pied légèrement.",stability+ball+balance,5
6,Glissement des bras au mur,"Thoracique, Posture, PDF 1",1-Haute,2,20,répétitions,45,"Assis au sol, dos et fesses contre le mur. Appuyez la tête (menton rentré), épaules, coudes et poignets au mur (coudes à 90 degrés). Glissez les bras vers le haut.",wall+slides+physio,3
7,Rétraction des omoplates (Bras hauts),"Dos, Renforcement, PDF 1",2-Moyenne,2,20,répétitions,45,"Couché sur le ventre, bras allongés vers le haut, pouces vers le plafond. Soulevez coudes et mains en rapprochant et abaissant les omoplates.",prone+scapular+retraction,3
8,Rétraction des omoplates (Mains à la tête),"Dos, Renforcement, PDF 1",2-Moyenne,2,10,répétitions,45,"Couché sur le ventre, mains derrière la tête. Soulevez les coudes de la surface en rapprochant vos omoplates ensemble sans tirer sur la nuque.",prone+retraction+hands+head,3
9,Rétraction des omoplates (Bras en W),"Dos, Renforcement, PDF 1",2-Moyenne,2,10,répétitions,45,"Couché sur le ventre, bras vers le haut, coudes fléchis à 90 degrés (forme de W), pouces vers le haut. Soulevez coudes et mains en serrant les omoplates.",prone+W+raise,3
10,Planche latérale avec extension et abduction,"Core, Fessiers, PDF 1",2-Moyenne,2,10,répétitions,45,"En planche latérale sur les genoux, levez la jambe supérieure vers le haut et l'arrière en diagonale avec rotation externe (orteils vers le haut).",side+plank+abduction,3
11,Planche latérale avec cercles de jambe,"Core, Fessiers, PDF 1",2-Moyenne,2,10,répétitions,45,"En planche latérale sur les genoux, jambe supérieure tendue. Effectuez des cercles contrôlés, orteils pointés vers le haut pour engager les fessiers.",side+plank+circles,3
12,Redressement assis partiel,"Abdominaux, Renforcement, PDF 1",3-Basse,1,15,répétitions,0,"Couché sur le dos, genoux pliés. Rentrez le menton. Soulevez tête et épaules en dirigeant les mains vers les genoux. Expirez en montant.",partial+crunch+physio,3
13,Maintien abdominal isométrique,"Abdominaux, Stabilité, PDF 1",2-Moyenne,1,15,répétitions,0,"Couché sur le dos, écrasez le sol avec le bas du dos (nombril rentré). Soulevez les épaules et les pieds à quelques centimètres du sol.",iso+abs+hold,3
14,Planche avec extension de la hanche,"Core, Fessiers, PDF 1",2-Moyenne,2,15,répétitions,45,"En planche sur les coudes, soulevez une jambe étendue sans arquer le dos. Maintenez la ligne droite tête-épaules-bassin.",plank+leg+lift,3
15,Série 5x5 Scapulaire (Y-U-T-W-I),"Épaules, Posture, PDF 2",1-Haute,5,5,répétitions,30,"Debout avec élastique. Formez successivement les lettres Y, U, T, W et I. Maintenez chaque position 3 secondes en gardant les omoplates basses.",YTW+scapular,3
16,Mouvement I-Y-T à quatre pattes,"Épaules, Stabilité, PDF 2",2-Moyenne,5,3,répétitions,30,"À quatre pattes, soulevez le bras en avant (I), en diagonale (Y) puis sur le côté (T). Stabilisez bien l'omoplate pendant le mouvement.",quadruped+IYT,3
17,Élévations latérales tronc penché,"Épaules, Dos, PDF 2",2-Moyenne,3,12,répétitions,45,"Genoux fléchis, penché vers l'avant, dos droit. Soulevez les poids sur le côté en ligne avec les épaules sans avancer la tête.",bent+over+lateral+raises,3
18,Stabilisation avec adduction horizontale,"Pectoraux, Stabilité, PDF 2",2-Moyenne,3,12,répétitions,45,"Dos sur le ballon (pont), corps en ligne droite. Levez les poids au plafond puis descendez-les sur les côtés avec coudes légèrement fléchis.",stability+ball+chest+fly,3
19,Auto-grandissement postural,"Posture, Cervical, PDF 3",1-Haute,1,10,répétitions,0,"Debout, imaginez une ficelle au sommet de votre tête qui vous tire vers le plafond. Allongez la colonne en respirant normalement.",auto+grandissement+physio,4
20,Extension et rétraction avec élastique,"Dos, Posture, PDF 3",1-Haute,2,10,répétitions,45,"Debout, tirez l'élastique vers l'arrière le plus loin possible en collant les omoplates et en reculant les coudes sans monter les épaules.",band+scapular+retraction,4
21,Toucher les orteils sur une jambe,"Équilibre, Jambes, PDF 3",2-Moyenne,4,10,répétitions,30,"En équilibre sur une jambe, penchez-vous vers l'avant (dos droit) pour toucher le sol. Utilisez les ischio-jambiers pour revenir debout.",single+leg+deadlift,4
22,Squat bulgare (Pied arrière élevé),"Jambes, Fessiers, PDF 3",1-Haute,4,10,répétitions,45,"Position de fente, pied arrière élevé sur une marche. Fléchissez les genoux pour abaisser le corps sans déplacer le poids vers l'avant.",bulgarian+split+squat,4
23,Planche abdominale classique,"Core, Renforcement, PDF 3",1-Haute,1,30,secondes,0,"En appui sur coudes et orteils, menton rentré. Soulevez le bassin pour créer une ligne droite. Ne laissez pas le bas du dos s'arquer.",plank+form,4
24,Pompes sur genoux (Amplitude de mouvement augmentée),"Pectoraux, Renforcement, PDF 3",2-Moyenne,3,10,répétitions,60,"Mains sur haltères, descendez en un bloc (ligne droite tête-genoux). Les haltères permettent de descendre plus bas qu'au sol.",push+ups+dumbbells,4
25,Renforcement en extension (Prone),"Dos, Chaîne postérieure, PDF 3",2-Moyenne,2,10,répétitions,45,"Couché sur le ventre, bras derrière la tête, menton rentré. Soulevez le haut du corps en rapprochant les omoplates sans lever les pieds.",prone+back+extension,4
26,Enfiler l'aiguille (Rotation thoracique),"Mobilité, Thoracique, PDF 3",1-Haute,2,10,répétitions,30,"À quatre pattes, passez une main sous le corps pour créer une rotation, puis ouvrez grand vers le plafond. Suivez la main du regard.",thread+the+needle,4
27,Étirement du muscle trapèze supérieur,"Cervical, Étirement, PDF 3",1-Haute,1,30,secondes,0,Bras derrière le dos pour abaisser l'épaule. Inclinez la tête du côté opposé et tournez-la légèrement. Maintenez l'étirement.,upper+trap+stretch,4
28,Étirement de l'élévateur de l'omoplate,"Cervical, Étirement, PDF 3",1-Haute,1,30,secondes,0,Main derrière la fesse. Tournez la tête à 45 degrés opposés et regardez vers le bas (aisselle). Tirez doucement avec l'autre main.,levator+scapulae+stretch,4
29,Mouvement Bird-Dog (Oiseau-Chien),"Core, Stabilité, Ajouts",1-Haute,3,10,répétitions,45,"À quatre pattes, tendez simultanément le bras et la jambe opposés en gardant le dos parfaitement stable.",bird+dog,3
30,Challenge Planche abdominale (2 minutes),"Challenge, Core, Ajouts",3-Basse,1,120,secondes,0,Maintenez la position de planche parfaite. Respirez profondément. Travail de l'endurance musculaire du centre.,plank+2+minutes,3
31,Série Y-U-T-W-I sur ballon de stabilité,"Dos, Épaules, Ajouts",2-Moyenne,3,10,répétitions,45,"Ventre sur le ballon, enchaînez les positions de bras pour renforcer toute la chaîne postérieure et les fixateurs d'omoplates.",ball+IYT,3"""

# Write to CSV
with open('exercices.csv', 'w', encoding='utf-8') as f:
    f.write(raw_data + '\n')

# Parse for JSON
lines = raw_data.strip().split('\n')
headers = lines[0].split(',')

data = []
for line in lines[1:]:
    # This uses csv module to correctly parse the comma separated line that might contain quotes
    reader = csv.reader([line])
    for row in reader:
        item = {}
        for i, h in enumerate(headers):
            # Try to convert to int/float if appropriate
            val = row[i]
            if val.isdigit():
                val = int(val)
            item[h] = val
        data.append(item)

# Write to JSON
with open('exercices.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("Files created successfully.")
